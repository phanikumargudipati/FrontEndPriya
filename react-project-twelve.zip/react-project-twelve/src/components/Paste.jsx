import React from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { useState } from 'react';
import { removeFromPastes } from '../redux/pasteSlice';
import toast from 'react-hot-toast';
import { Link } from 'react-router-dom';

const Paste = () => {
  const pastes = useSelector((state) => state.paste.pastes);
  const [searchTerm, setSearchTerm] = useState('');
  const dispatch = useDispatch();

  const filteredData = pastes.filter((paste) =>
    paste.title.toLowerCase().includes(searchTerm.toLowerCase())
  );

  function handleDelete(pasteId) {
    dispatch(removeFromPastes(pasteId));
  }

  function handleShare(paste) {
    const shareUrl = `${window.location.origin}/pastes/${paste._id}`;
    const shareData = {
      title: paste.title,
      text: paste.content,
      url: shareUrl,
    };

    if (navigator.share) {
      navigator
        .share(shareData)
        .then(() => toast.success('Shared successfully!'))
        .catch((error) => toast.error('Sharing failed.'));
    } else {
      navigator.clipboard.writeText(shareUrl);
      toast('Link copied to clipboard (Share not supported)');
    }
  }

  return (
    <div>
      <input
        className='p-2 rounded-2xl min-w-[600px] mt-5'
        type='search'
        placeholder='Search here'
        value={searchTerm}
        onChange={(e) => setSearchTerm(e.target.value)}
      />

      <div className='flex flex-col gap-5 mt-5'>
        {filteredData.length > 0 &&
          filteredData.map((paste) => (
            <div className='border p-2' key={paste?._id}>
              <div>{paste.title}</div>
              <div>{paste.content}</div>
              <div className='flex flex-row gap-2 place-content-evenly'>
                <button>
                  <Link to={`/?pasteId=${paste?._id}`}>Edit</Link>
                </button>
                <button>
                  <Link to={`/pastes/${paste?._id}`}>View</Link>
                </button>
                <button onClick={() => handleDelete(paste?._id)}>Delete</button>
                <button
                  onClick={() => {
                    navigator.clipboard.writeText(paste?.content);
                    toast.success('Copied to clipboard');
                  }}
                >
                  Copy
                </button>
                <button onClick={() => handleShare(paste)}>Share</button>
              </div>
              <div>{paste.createdAt}</div>
            </div>
          ))}
      </div>
    </div>
  );
};

export default Paste;
