import React from 'react';
import { useParams } from 'react-router-dom';
import { useSelector } from 'react-redux';

const ViewPaste = () => {
  const { id } = useParams();

  const paste = useSelector((state) =>
    state.paste.pastes.find((item) => item._id === id)
  );

  if (!paste) {
    return <div className="text-red-500 mt-10 text-center">Paste not found</div>;
  }

  return (
    <div className="p-5 max-w-4xl mx-auto">
      <div className="flex flex-row gap-7 justify-between">
        <input
          className="p-2 rounded-2xl mt-2 w-[66%] pl-4 border"
          type="text"
          placeholder="Enter your title here"
          value={paste.title}
          disabled
        />
      </div>

      <div className="mt-8">
        <textarea
          className="rounded-2xl min-w-[500px] p-4 border w-full"
          value={paste.content}
          placeholder="Enter your Content here"
          disabled
          rows={20}
        />
      </div>
    </div>
  );
};

export default ViewPaste;
